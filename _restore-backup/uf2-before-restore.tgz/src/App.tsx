import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './auth/AuthProvider';
import { ToastProvider } from './components/ui/Toast';
import { ProtectedRoute } from './auth/ProtectedRoute';
import { AppShell } from './components/layout/AppShell';
import { LoginPage } from './auth/LoginPage';
import { HomePage } from './pages/HomePage';
import { CreatePage } from './pages/CreatePage';
import { ModelsPage } from './pages/ModelsPage';
import { StudioPage } from './pages/StudioPage';
import { TemplatesPage } from './pages/TemplatesPage';
import { GalleryPage } from './pages/GalleryPage';
import { LibraryPage } from './pages/LibraryPage';
import { LibraryNewAssetPage } from './pages/LibraryNewAssetPage';
import { LibraryLooksPage } from './pages/LibraryLooksPage';
import { LibraryNewLookPage } from './pages/LibraryNewLookPage';
import { LibraryLookProfilePage } from './pages/LibraryLookProfilePage';
import { LibraryAssetProfileLayout } from './features/library/LibraryAssetProfileLayout';
import {
  LibraryDetailsRoute,
  LibraryOverviewRoute,
  LibraryReferencesRoute,
  LibraryVersionsRoute,
} from './features/library/tabRoutes';
import { CampaignsPage } from './pages/CampaignsPage';
import { WorkspacePage } from './pages/WorkspacePage';
import { SettingsPage } from './pages/SettingsPage';
import { HelpPage } from './pages/HelpPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { ModelProfileLayout } from './features/models/ModelProfileLayout';
import {
  ModelCharacterSheetRoute,
  ModelClosetPropsRoute,
  ModelLooksRoute,
  ModelOverviewRoute,
  ModelUsageHistoryRoute,
  ModelVersionsRoute,
} from './features/models/tabRoutes';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route
              element={
                <ProtectedRoute>
                  <AppShell />
                </ProtectedRoute>
              }
            >
              <Route index element={<HomePage />} />
              <Route path="create" element={<CreatePage />} />
              <Route path="models" element={<ModelsPage />} />
              <Route path="models/:modelId" element={<ModelProfileLayout />}>
                <Route index element={<ModelOverviewRoute />} />
                <Route path="character-sheet" element={<ModelCharacterSheetRoute />} />
                <Route path="versions" element={<ModelVersionsRoute />} />
                <Route path="looks" element={<ModelLooksRoute />} />
                <Route path="closet-props" element={<ModelClosetPropsRoute />} />
                <Route path="usage-history" element={<ModelUsageHistoryRoute />} />
              </Route>
              <Route path="studio" element={<StudioPage />} />
              <Route path="templates" element={<TemplatesPage />} />
              <Route path="gallery" element={<GalleryPage />} />
              <Route path="library" element={<LibraryPage />} />
              <Route path="library/new" element={<LibraryNewAssetPage />} />
              <Route path="library/looks" element={<LibraryLooksPage />} />
              <Route path="library/looks/new" element={<LibraryNewLookPage />} />
              <Route path="library/looks/:assetId" element={<LibraryLookProfilePage />} />
              <Route path="library/:assetId" element={<LibraryAssetProfileLayout />}>
                <Route index element={<LibraryOverviewRoute />} />
                <Route path="details" element={<LibraryDetailsRoute />} />
                <Route path="references" element={<LibraryReferencesRoute />} />
                <Route path="versions" element={<LibraryVersionsRoute />} />
              </Route>
              <Route path="campaigns" element={<CampaignsPage />} />
              <Route path="workspace" element={<WorkspacePage />} />
              <Route path="settings" element={<SettingsPage />} />
              <Route path="help" element={<HelpPage />} />
              <Route path="*" element={<NotFoundPage />} />
            </Route>
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
