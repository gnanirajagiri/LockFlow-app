/**
 * TEMPORARY scratch test — reproduces useUsageSummary's service call
 * sequence directly against the mock repositories to find which call
 * returns empty or throws. Delete after diagnosis.
 */
import { describe, it } from 'vitest';
import { ContentStudioService } from '../services/contentService';
import { GalleryService } from '../services/galleryService';
import { LibraryService } from '../services/libraryService';
import { ModelsService } from '../services/modelsService';
import { EnvironmentsService } from '../services/environmentsService';
import { getContentRepository } from '../data/contentFactory';
import { getGalleryRepository } from '../data/galleryFactory';
import { getLibraryRepository } from '../data/libraryFactory';
import { getModelsRepository } from '../data';
import { getEnvironmentsRepository } from '../data/environmentsFactory';
import { SEED_LIBRARY_WORKSPACE_ID as WS } from '../mock/librarySeed';

describe('scratch: usage summary call chain', () => {
  it('walks the hook sequence', async () => {
    const content = new ContentStudioService(getContentRepository(), {
      library: new LibraryService(getLibraryRepository()),
      models: new ModelsService(getModelsRepository()),
      environments: new EnvironmentsService(getEnvironmentsRepository()),
    });
    const gallery = new GalleryService(getGalleryRepository(), content, WS);

    const projects = await content.listProjects(WS);
    console.log('projects:', projects.length, projects.map((p) => p.id));

    for (const project of projects) {
      const inputs = await content.listProjectInputs(project.id, WS).catch((e: unknown) => {
        console.log('listProjectInputs FAILED for', project.id, e);
        return [];
      });
      console.log('project', project.id, 'inputs:', inputs.length);
    }

    const outputs = await gallery.listOutputs(WS).catch((e: unknown) => {
      console.log('listOutputs FAILED', e);
      return [];
    });
    console.log('outputs:', outputs.length, outputs.map((o) => o.id));

    for (const output of outputs) {
      const provenance = await gallery.resolveProvenance(output.id, WS).catch((e: unknown) => {
        console.log('resolveProvenance FAILED for', output.id, e);
        return null;
      });
      console.log(
        'output', output.id, 'pins:',
        provenance ? provenance.pins.map((p) => `${p.pinType}:${p.sourceRecordId}`) : 'null',
      );
    }
  });
});
